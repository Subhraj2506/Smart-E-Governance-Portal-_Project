# Frontend - Smart E-Governance Portal

Commands:
- Install: npm install
- Dev: npm run dev (open http://localhost:5173)
- Build: npm run build
- Preview: npm run preview

Set REACT_APP_API_URL to point to backend API (e.g., http://localhost:8080)
