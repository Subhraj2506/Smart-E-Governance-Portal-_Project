import React from 'react'
export default function CitizenDashboard(){
  return (<div className='p-8'><h1 className='text-2xl font-bold'>Citizen Dashboard</h1><p className='mt-4'>Apply for services, upload documents, and track requests.</p></div>)
}
