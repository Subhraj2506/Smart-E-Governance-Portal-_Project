# Smart E-Governance Portal - PR Package

This package is a Pull-Request-ready starter containing:
- Backend: Spring Boot (Dockerfile, entrypoint, JWT via env)
- Frontend: React (Vite) with Tailwind and multi-page UI (separate folder)
- docker-compose for local testing

## How to use
1. Extract and review files
2. Copy backend/ and frontend/ into your GitHub repo root (or create separate folders)
3. Commit and push
4. Deploy backend on Railway (connect repo, add Postgres plugin, set env vars)
5. Deploy frontend on Vercel (set REACT_APP_API_URL to Railway backend URL)

See `/frontend/README.frontend.md` for frontend dev commands.
