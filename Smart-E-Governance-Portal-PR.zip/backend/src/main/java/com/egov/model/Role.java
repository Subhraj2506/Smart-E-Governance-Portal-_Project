package com.egov.model;
public enum Role { ROLE_CITIZEN, ROLE_ADMIN }
