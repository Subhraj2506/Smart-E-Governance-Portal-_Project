package com.egov;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EgovBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(EgovBackendApplication.class, args);
    }
}
